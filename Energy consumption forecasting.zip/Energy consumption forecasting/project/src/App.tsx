import React, { useState } from 'react';
import { LineChart, BarChart, Activity, TrendingUp, Download } from 'lucide-react';

interface ConsumptionData {
  month: string;
  usage: number;
}

function App() {
  const [historicalData, setHistoricalData] = useState<ConsumptionData[]>([
    { month: 'Jan', usage: 250 },
    { month: 'Feb', usage: 230 },
    { month: 'Mar', usage: 210 },
    { month: 'Apr', usage: 180 },
    { month: 'May', usage: 200 },
    { month: 'Jun', usage: 220 }
  ]);

  const [newUsage, setNewUsage] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('Jul');

  const forecast = () => {
    // Simple moving average forecast
    const last3Months = historicalData.slice(-3);
    const average = last3Months.reduce((acc, curr) => acc + curr.usage, 0) / 3;
    return Math.round(average);
  };

  const handleAddData = (e: React.FormEvent) => {
    e.preventDefault();
    if (newUsage && selectedMonth) {
      setHistoricalData([...historicalData, {
        month: selectedMonth,
        usage: Number(newUsage)
      }]);
      setNewUsage('');
    }
  };

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">EnergyForecast</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Stats Cards */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <LineChart className="h-8 w-8 text-blue-600" />
              <h3 className="ml-2 text-lg font-medium text-gray-900">Current Usage</h3>
            </div>
            <p className="mt-4 text-3xl font-semibold text-gray-900">
              {historicalData[historicalData.length - 1]?.usage || 0} kWh
            </p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-green-600" />
              <h3 className="ml-2 text-lg font-medium text-gray-900">Forecasted Usage</h3>
            </div>
            <p className="mt-4 text-3xl font-semibold text-gray-900">{forecast()} kWh</p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <BarChart className="h-8 w-8 text-purple-600" />
              <h3 className="ml-2 text-lg font-medium text-gray-900">Average Usage</h3>
            </div>
            <p className="mt-4 text-3xl font-semibold text-gray-900">
              {Math.round(historicalData.reduce((acc, curr) => acc + curr.usage, 0) / historicalData.length)} kWh
            </p>
          </div>
        </div>

        {/* Input Form */}
        <div className="mt-8 bg-white rounded-lg shadow">
          <div className="p-6">
            <h2 className="text-lg font-medium text-gray-900">Add New Consumption Data</h2>
            <form onSubmit={handleAddData} className="mt-4 flex gap-4">
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                {months.map(month => (
                  <option key={month} value={month}>{month}</option>
                ))}
              </select>
              <input
                type="number"
                value={newUsage}
                onChange={(e) => setNewUsage(e.target.value)}
                placeholder="Usage in kWh"
                className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Add Data
              </button>
            </form>
          </div>
        </div>

        {/* Historical Data Table */}
        <div className="mt-8 bg-white rounded-lg shadow">
          <div className="p-6">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-medium text-gray-900">Historical Consumption</h2>
              <button className="flex items-center text-blue-600 hover:text-blue-800">
                <Download className="h-4 w-4 mr-1" />
                Export Data
              </button>
            </div>
            <div className="mt-4 overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Month
                    </th>
                    <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Usage (kWh)
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {historicalData.map((data, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.month}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{data.usage}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;